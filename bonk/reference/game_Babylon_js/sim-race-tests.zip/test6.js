const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  // ---- phone: results card layout
  const ctx = await browser.newContext({ viewport: { width: 390, height: 700 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
  const m = await ctx.newPage();
  const logs = [];
  m.on('console', x => logs.push('m ' + x.type() + ': ' + x.text()));
  m.on('pageerror', e => logs.push('m PAGEERROR: ' + e.message));
  await m.goto('file:///home/claude/build/sim-race.html');
  await m.waitForTimeout(600);
  await m.tap('#btnPlay');
  await m.waitForTimeout(300);
  await m.evaluate(() => { const s = window.__race.sim; for (let i = 0; i < 80; i++) s.step(0.05, null); const p = s.players[window.__race.me]; p.x = 0; p.y = 3.05; p.z = 181.5; p.vx = p.vz = p.vy = 0; p.ground = null; });
  const cdp = await ctx.newCDPSession(m);
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: 90, y: 560, id: 1 }] });
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: 90, y: 500, id: 1 }] });
  let waited = 0;
  while (waited < 14000 && await m.evaluate(() => document.getElementById('results').classList.contains('hidden'))) { await m.waitForTimeout(250); waited += 250; }
  console.log('waited ms for results:', waited, JSON.stringify(await m.evaluate(() => { const p = window.__race.sim.players[window.__race.me]; return { finished: p.finished, z: +p.z.toFixed(1), y: +p.y.toFixed(2), ground: !!p.ground, dead: p.dead, stun: p.stun, phase: window.__race.sim.phase }; })));
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  console.log('phone results visible:', await m.evaluate(() => !document.getElementById('results').classList.contains('hidden')), await m.evaluate(() => document.getElementById('resHead').textContent));
  await m.screenshot({ path: '/home/claude/build/m_results.png' });
  await m.tap('#btnAgain');
  await m.waitForTimeout(500);
  console.log('after Race again -> phase:', await m.evaluate(() => window.__race.sim.phase), 'results hidden:', await m.evaluate(() => document.getElementById('results').classList.contains('hidden')));

  // ---- desktop soak: random inputs for a while, watch for errors
  const page = await browser.newPage({ viewport: { width: 800, height: 500 } });
  page.on('console', x => logs.push('d ' + x.type() + ': ' + x.text()));
  page.on('pageerror', e => logs.push('d PAGEERROR: ' + e.message));
  await page.goto('file:///home/claude/build/sim-race.html');
  await page.waitForTimeout(500);
  await page.keyboard.press('Enter');             // keyboard start
  await page.waitForTimeout(300);
  console.log('Enter starts game, mode:', await page.evaluate(() => window.__race.mode));
  await page.evaluate(() => { const s = window.__race.sim; for (let i = 0; i < 80; i++) s.step(0.05, null); });
  await page.keyboard.down('KeyW');
  const t0 = Date.now(); let n = 0;
  while (Date.now() - t0 < 20000) {
    const r = Math.random();
    if (r < 0.2) await page.keyboard.press('Space');
    else if (r < 0.3) await page.keyboard.press('ShiftLeft');
    else if (r < 0.4) { await page.keyboard.down('KeyF'); await page.waitForTimeout(80); await page.keyboard.up('KeyF'); }
    else if (r < 0.55) { await page.keyboard.down('KeyA'); await page.waitForTimeout(120); await page.keyboard.up('KeyA'); }
    else if (r < 0.7) { await page.keyboard.down('KeyD'); await page.waitForTimeout(120); await page.keyboard.up('KeyD'); }
    await page.evaluate(() => { const s = window.__race.sim; for (let i = 0; i < 6; i++) s.step(0.05, { mx: 0, mz: 1 }); });
    await page.waitForTimeout(60); n++;
  }
  await page.keyboard.up('KeyW');
  const st = await page.evaluate(() => { const s = window.__race.sim, p = s.players[window.__race.me]; return { raceT: +s.raceT.toFixed(1), z: +p.z.toFixed(1), falls: p.falls, bonks: p.bonks, err: !!document.getElementById('errBar') }; });
  console.log('soak iterations', n, JSON.stringify(st));
  await page.keyboard.press('KeyR'); await page.waitForTimeout(300);
  console.log('R restarts, phase:', await page.evaluate(() => window.__race.sim.phase));
  await page.keyboard.press('Escape'); await page.waitForTimeout(300);
  console.log('Esc -> mode:', await page.evaluate(() => window.__race.mode));
  console.log(logs.join('\n') || '(no console output)');
  await browser.close();
})();
