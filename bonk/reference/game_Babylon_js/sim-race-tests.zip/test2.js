const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1000, height: 620 } });
  const logs = [];
  page.on('console', m => logs.push(m.type() + ': ' + m.text()));
  page.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await page.goto('file:///home/claude/build/sim-race.html');
  await page.waitForTimeout(800);
  await page.click('#btnPlay');
  await page.waitForTimeout(700);
  await page.screenshot({ path: '/home/claude/build/shot_count.png' });
  console.log('phase after play:', await page.evaluate(() => window.__race.sim.phase + ' cd=' + window.__race.sim.cd.toFixed(2)));
  await page.waitForTimeout(2800);
  await page.keyboard.down('KeyW');
  await page.waitForTimeout(1500);
  await page.keyboard.press('Space');
  await page.waitForTimeout(2500);
  await page.screenshot({ path: '/home/claude/build/shot_race1.png' });
  const st = await page.evaluate(() => { const s = window.__race.sim, p = s.players[window.__race.me]; return { phase: s.phase, raceT: +s.raceT.toFixed(1), z: +p.z.toFixed(1), x: +p.x.toFixed(2), y: +p.y.toFixed(2), place: document.getElementById('placeN').textContent, timer: document.getElementById('timer').textContent, ammo: p.ammo, falls: p.falls }; });
  console.log('after running forward:', JSON.stringify(st));
  await page.keyboard.up('KeyW');
  // dive + fire pulses should not throw
  await page.keyboard.press('ShiftLeft'); await page.waitForTimeout(300); await page.keyboard.down('KeyF'); await page.waitForTimeout(300); await page.keyboard.up('KeyF');
  // teleport onto the finish slab and run over the line
  await page.evaluate(() => { const s = window.__race.sim, p = s.players[window.__race.me]; p.x = 0; p.y = 3.05; p.z = 178; p.vx = p.vz = 0; p.stun = 0; p.diveT = 0; p.dead = 0; });
  await page.keyboard.down('KeyW');
  await page.waitForTimeout(1400);
  await page.screenshot({ path: '/home/claude/build/shot_finish.png' });
  await page.waitForTimeout(1600);
  await page.keyboard.up('KeyW');
  const fin = await page.evaluate(() => { const p = window.__race.sim.players[window.__race.me]; return { finished: p.finished, place: p.place, t: +p.finishT.toFixed(1), results: !document.getElementById('results').classList.contains('hidden'), head: document.getElementById('resHead').textContent }; });
  console.log('finish:', JSON.stringify(fin));
  await page.screenshot({ path: '/home/claude/build/shot_results.png' });
  console.log(logs.join('\n') || '(no console output)');
  await browser.close();
})();
