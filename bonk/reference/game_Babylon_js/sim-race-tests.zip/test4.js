const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 900, height: 560 } });
  const logs = [];
  page.on('console', m => logs.push(m.type() + ': ' + m.text()));
  page.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await page.goto('file:///home/claude/build/sim-race.html');
  await page.waitForTimeout(600);
  await page.click('#btnPlay');
  await page.waitForTimeout(400);
  await page.evaluate(() => { const s = window.__race.sim; for (let i = 0; i < 80; i++) s.step(0.05, null); });
  const stops = [
    ['alley', 14, 0], ['sliders', 52, 0], ['tiles', 68, 0], ['bridge', 92, 1.5], ['pad', 118, 1.5], ['disc', 146, 2.5], ['final', 164, 2.5]
  ];
  for (const [name, z, top] of stops) {
    await page.evaluate(([z, top]) => { const s = window.__race.sim, p = s.players[window.__race.me]; p.x = 0; p.y = top + 0.05; p.z = z; p.vx = p.vz = p.vy = 0; p.stun = 0; p.diveT = 0; p.dead = 0; }, [z, top]);
    await page.waitForTimeout(900);
    await page.screenshot({ path: `/home/claude/build/tour_${name}.png` });
  }
  console.log(logs.join('\n') || '(no console output)');
  await browser.close();
})();
