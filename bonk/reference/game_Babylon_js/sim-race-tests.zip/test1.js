const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-webgl'] });
  const page = await browser.newPage({ viewport: { width: 1000, height: 620 } });
  const logs = [];
  page.on('console', m => logs.push(m.type() + ': ' + m.text()));
  page.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await page.goto('file:///home/claude/build/sim-race.html');
  await page.waitForTimeout(2500);
  const hasGL = await page.evaluate(() => { const c = document.createElement('canvas'); return !!(c.getContext('webgl')); });
  console.log('webgl available in page:', hasGL);
  console.log('mode:', await page.evaluate(() => window.__race && window.__race.mode));
  await page.screenshot({ path: '/home/claude/build/shot_menu.png' });
  console.log(logs.join('\n') || '(no console output)');
  await browser.close();
})();
