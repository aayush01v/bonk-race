const Sim = require('/mnt/user-data/uploads/sim.js');
const skills = [0.6, 0.7, 0.8, 0.9, 0.55];
const S = Sim.create(7);
S.addPlayer({ name: 'You', bot: false, kind: 'zombie' });
skills.forEach((k, i) => S.addPlayer({ name: 'Bot' + i, bot: true, skill: k }));
S.humanId = 0;
S.begin();
const dt = 1 / 60;
let frames = 0;
while (frames < 60 * 120) {
  S.step(dt, { mx: 0, mz: 0, jump: false, dive: false, fire: false });
  S.ev.length = 0;
  frames++;
  if (S.players.filter(p => p.bot).every(p => p.finished)) break;
}
console.log('phase', S.phase, 'raceT', S.raceT.toFixed(1), 'frames', frames);
S.players.forEach(p => console.log(p.name, 'bot', p.bot, 'finished', p.finished, 'place', p.place, 'time', p.finishT.toFixed(1), 'falls', p.falls, 'bonks', p.bonks, 'cp', p.cp, 'z', p.z.toFixed(1)));
console.log('solids', S.solids.length, 'shapes', [...new Set(S.solids.map(s => s.shape))].join(','), 'deco', [...new Set(S.deco.map(s => s.shape))].join(','));
