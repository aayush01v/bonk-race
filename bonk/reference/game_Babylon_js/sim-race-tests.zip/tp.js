const Sim = require('/mnt/user-data/uploads/sim.js');
function trial(z, y, steps0) {
  const S = Sim.create(5);
  S.addPlayer({ name: 'You', bot: false, kind: 'zombie' }); S.humanId = 0;
  for (let i = 0; i < 4; i++) S.addPlayer({ name: 'b' + i, bot: true, skill: 0.7 });
  S.begin();
  for (let i = 0; i < steps0; i++) S.step(0.05, null);
  const p = S.players[0]; p.x = 0; p.y = y; p.z = z; p.vx = p.vz = 0;
  const out = [];
  for (let i = 0; i < 20; i++) { S.step(1 / 60, { mx: 0, mz: 0 }); if (i % 4 === 0) out.push(+p.y.toFixed(2) + (p.ground ? 'G' : '')); }
  return `z=${z} y0=${y} after ${steps0} pre-steps: ${out.join(' ')} | finished=${p.finished}`;
}
console.log(trial(178, 3.05, 80));
console.log(trial(181.5, 3.05, 80));
console.log(trial(181.5, 3.05, 0));
console.log(trial(181.5, 3.05, 5));
