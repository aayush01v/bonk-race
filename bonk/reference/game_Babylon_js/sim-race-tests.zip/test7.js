const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 700 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
  const m = await ctx.newPage();
  m.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await m.goto('file:///home/claude/build/sim-race.html');
  await m.waitForTimeout(600);
  await m.tap('#btnPlay');
  await m.waitForTimeout(300);
  console.log('mode', await m.evaluate(() => window.__race.mode), 'phase', await m.evaluate(() => window.__race.sim.phase));
  await m.evaluate(() => { const s = window.__race.sim; for (let i = 0; i < 80; i++) s.step(0.05, null); const p = s.players[window.__race.me]; p.x = 0; p.y = 3.05; p.z = 181.5; p.vx = p.vz = 0; window.__log = []; const f = () => { const q = s.players[window.__race.me]; window.__log.push([+q.x.toFixed(2), +q.y.toFixed(2), +q.z.toFixed(2), q.ground ? q.ground.name || q.ground.shape : null, q.dead > 0 ? 'dead' : '', q.falls, q.finished ? 'FIN' : '']); }; window.__iv = setInterval(f, 250); });
  await m.waitForTimeout(3000);
  console.log(JSON.stringify(await m.evaluate(() => window.__log)));
  await browser.close();
})();
