const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 780 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
  const page = await ctx.newPage();
  const logs = [];
  page.on('console', m => logs.push(m.type() + ': ' + m.text()));
  page.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await page.goto('file:///home/claude/build/sim-race.html');
  await page.waitForTimeout(1200);
  await page.screenshot({ path: '/home/claude/build/m_menu.png' });
  await page.tap('.chip[data-k="robot"]');
  await page.tap('#btnPlay');
  await page.waitForTimeout(500);
  // fast-forward the countdown without waiting on the slow software renderer
  await page.evaluate(() => { const s = window.__race.sim; for (let i = 0; i < 80; i++) s.step(0.05, null); });
  await page.waitForTimeout(500);
  const cdp = await ctx.newCDPSession(page);
  const touch = (type, pts) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts });
  const z0 = await page.evaluate(() => window.__race.sim.players[window.__race.me].z);
  // drag joystick up (forward), keep it held
  await touch('touchStart', [{ x: 90, y: 600, id: 1 }]);
  await touch('touchMove', [{ x: 92, y: 540, id: 1 }]);
  await page.waitForTimeout(1500);
  // tap jump while still holding the joystick (second finger)
  await touch('touchStart', [{ x: 92, y: 540, id: 1 }, { x: 330, y: 700, id: 2 }]);
  await touch('touchEnd', [{ x: 92, y: 540, id: 1 }]);
  await page.waitForTimeout(250);
  const mid = await page.evaluate(() => { const p = window.__race.sim.players[window.__race.me]; return { z: +p.z.toFixed(2), y: +p.y.toFixed(2), vz: +p.vz.toFixed(2), grounded: !!p.ground }; });
  await page.screenshot({ path: '/home/claude/build/m_play.png' });
  await touch('touchEnd', []);
  console.log('z0', z0.toFixed(2), 'after joystick+jump:', JSON.stringify(mid));
  console.log('touch UI visible:', await page.evaluate(() => !document.getElementById('touch').classList.contains('hidden')));
  console.log(logs.join('\n') || '(no console output)');
  await browser.close();
})();
