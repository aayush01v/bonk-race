Verification scripts used while building Sim Race (not needed to run the game).

They have my sandbox paths hard-coded: /home/claude/build/sim-race.html,
/mnt/user-data/uploads/sim.js and the Playwright install path. Edit those at
the top of each file to run them on your machine.

Node only (no browser):
  smoke.js    runs sim.js headless with 5 bots and prints finish times
  inspect.js  prints the field names the sim exposes (solids, deco, players)
  tp.js       probe: teleport a racer onto the finish slab and watch it fall

Playwright + headless Chromium:
  test1.js    loads the page, checks WebGL, screenshots the title screen
  test2.js    desktop playthrough: countdown, run, jump, dive, fire, finish, results
  test3.js    phone emulation: menu layout, joystick and jump touches
  test4.js    first obstacle tour (superseded by test5.js)
  test5.js    obstacle tour plus character poses, with the sim paused
  test6.js    phone results card, Enter/R/Esc keys, 20 s random-input soak
  test7.js    debug probe: logs the racer's position after a teleport
