const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 900, height: 560 } });
  const logs = [];
  page.on('console', m => logs.push(m.type() + ': ' + m.text()));
  page.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await page.goto('file:///home/claude/build/sim-race.html');
  await page.waitForTimeout(600);
  await page.click('#btnPlay');
  await page.waitForTimeout(400);
  await page.evaluate(() => { const s = window.__race.sim; for (let i = 0; i < 80; i++) s.step(0.05, null); window.__race.pause(true); });
  const put = (p, x, y, z) => { p.x = x; p.y = y; p.z = z; p.vx = p.vz = p.vy = 0; p.stun = 0; p.diveT = 0; p.dead = 0; p.ground = null; };
  const stops = [['alley', 0, 0.05, 11], ['tiles', -3, 0.45, 69], ['bridge', 0, 1.55, 87.5], ['pad', 0, 1.55, 121.5], ['disc', 0, 3.05, 146], ['final', 0, 3.05, 166]];
  for (const [name, x, y, z] of stops) {
    await page.evaluate(([x, y, z]) => { const s = window.__race.sim, p = s.players[window.__race.me]; p.x = x; p.y = y; p.z = z; p.vx = p.vz = p.vy = 0; p.stun = 0; p.diveT = 0; p.dead = 0; p.protect = 0; }, [x, y, z]);
    await page.waitForTimeout(700);
    await page.screenshot({ path: `/home/claude/build/tour_${name}.png` });
  }
  // poses: stunned, diving, airborne, running bots near the human in the alley
  await page.evaluate(() => {
    const s = window.__race.sim, me = s.players[window.__race.me], others = s.players.filter(q => q.id !== me.id);
    const set = (q, x, y, z, f) => { Object.assign(q, { x, y, z, vx: 0, vz: 0, vy: 0, stun: 0, diveT: 0, dead: 0, protect: 0, yaw: 0, ground: null }, f || {}); };
    set(me, 0, 0.05, 8);
    set(others[0], -2.6, 0.05, 11, { stun: 0.25, stunMax: 0.8, flop: 1 });
    set(others[1], 2.4, 0.05, 11, { diveT: 0.3 });
    set(others[2], -1.2, 1.4, 13.5, { vy: 5 });
    set(others[3], 1.2, 0.05, 13.5, { vz: 7.4, ground: s.solids[0] });
    set(others[4], 0, 0.05, 11, { stun: 0.5, stunMax: 0.8, flop: -1 });
    s.bullets.push({ x: 0.4, y: 1.0, z: 12.5, vx: 0, vz: 26, life: 0.9, owner: me.id });
  });
  await page.waitForTimeout(900);
  await page.screenshot({ path: '/home/claude/build/tour_poses.png' });
  console.log(logs.join('\n') || '(no console output)');
  await browser.close();
})();
